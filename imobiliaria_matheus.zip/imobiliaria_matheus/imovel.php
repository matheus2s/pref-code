<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Cadastro de Imóvel</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <header class="topo">
    <h1>Sistema de IPTU</h1>
  </header>

  <main class="conteudo">
    <h2 class="titulo">Cadastro de Imóvel</h2>

    <form action="cadastrar_imovel.php" method="POST">
      <div class="campo">
        <label for="logradouro" class="rotulo">Logradouro </label>
        <input type="text" id="logradouro" name="logradouro" required />
      </div>

      <div class="campo">
        <label for="numero" class="rotulo">Número</label>
        <input type="text" id="numero" name="numero" required />
      </div>

      <div class="campo">
        <label for="bairro" class="rotulo">Bairro </label>
        <input type="text" id="bairro" name="bairro" required />
      </div>

      <div class="campo">
        <label for="complemento" class="rotulo">Complemento</label>
        <input type="text" id="complemento" name="complemento" />
      </div>

      <div class="campo">
        <label for="contribuinte_id" class="rotulo">Proprietário</label>
        <select id="contribuinte_id" name="contribuinte_id" required>
          <option value="">Selecione um proprietário</option>
          <?php
            require_once 'conexao.php';
            $resultado = mysqli_query($conn, "SELECT id, nome FROM pessoas ORDER BY nome");
            while ($linha = mysqli_fetch_assoc($resultado)) {
              echo "<option value='{$linha['id']}'>{$linha['nome']}</option>";
            }
          ?>
        </select>
      </div>

      <div class="botoes">
        <button type="submit">Cadastrar</button>
        <a href="index.html" class="botao-voltar">Voltar</a>
      </div>
    </form>
  </main>

</body>
</html>
