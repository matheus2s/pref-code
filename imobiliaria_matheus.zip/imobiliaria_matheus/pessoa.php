<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Cadastro de Pessoa</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <header class="topo">
    <h1>Sistema de IPTU</h1>
  </header>

  <main class="conteudo">
    <h2 class="titulo">Cadastro de Pessoa</h2>

    <form action="cadastrar_pessoa.php" method="POST">
      <div class="campo">
        <label for="nome" class="rotulo">Nome *</label>
        <input type="text" id="nome" name="nome" required />
      </div>

      <div class="campo">
        <label for="data_nascimento" class="rotulo">Data de Nascimento *</label>
        <input type="date" id="data_nascimento" name="data_nascimento" required />
      </div>

      <div class="campo">
        <label for="cpf" class="rotulo">CPF *</label>
        <input type="text" id="cpf" name="cpf" required />
      </div>

      <div class="campo">
        <label for="sexo" class="rotulo">Sexo *</label>
        <select id="sexo" name="sexo" required>
          <option value="">Selecione</option>
          <option value="Masculino">Masculino</option>
          <option value="Feminino">Feminino</option>
          <option value="Outro">Outro</option>
        </select>
      </div>

      <div class="campo">
        <label for="telefone" class="rotulo">Telefone</label>
        <input type="text" id="telefone" name="telefone" />
      </div>

      <div class="campo">
        <label for="email" class="rotulo">Email</label>
        <input type="email" id="email" name="email" />
      </div>

      <div class="botoes">
        <button type="submit">Cadastrar</button>
        <a href="index.html" class="botao-voltar">Voltar</a>
      </div>
    </form>
  </main>

</body>
</html>
