<?php
require_once 'conexao.php';

$nome = $_POST['nome'];
$data_nascimento = $_POST['data_nascimento'];
$cpf = $_POST['cpf'];
$sexo = $_POST['sexo'];
$telefone = $_POST['telefone'] ?? null;
$email = $_POST['email'] ?? null;

$verifica = $conn->prepare("SELECT id FROM pessoas WHERE nome = ?");
$verifica->bind_param("s", $nome);
$verifica->execute();
$resultado = $verifica->get_result();

if ($resultado->num_rows > 0) {
    header("Location: mensagem_erro.php?mensagem=" . urlencode("Já existe uma pessoa cadastrada com esse nome."));
    exit();
}


$sql = "INSERT INTO pessoas (nome, data_nascimento, cpf, sexo, telefone, email) 
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $nome, $data_nascimento, $cpf, $sexo, $telefone, $email);

if ($stmt->execute()) {
    header("Location: mensagem_sucesso.php?tipo=pessoa");
    exit();
} else {
    echo "Erro ao cadastrar pessoa: " . $conn->error;
}

$stmt->close();
$conn->close();
?>