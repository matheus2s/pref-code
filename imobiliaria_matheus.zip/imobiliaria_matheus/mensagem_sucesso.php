<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cadastro Bem-Sucedido</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: sans-serif;
      background: #f2f2f2;
      margin: 0;
      padding: 0;
    }
    .mensagem {
      max-width: 600px;
      margin: 100px auto;
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .mensagem h2 {
      color: #2ecc71;
      margin-bottom: 20px;
    }
    .botao {
      margin-top: 25px;
      display: inline-block;
      padding: 10px 20px;
      background: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 5px;
    }
    .botao:hover {
      background: #2980b9;
    }
  </style>
</head>
<body>
  <div class="mensagem">
    <?php
      $tipo = $_GET['tipo'] ?? '';
      if ($tipo === 'pessoa') {
        echo "<h2>✅ Pessoa cadastrada com sucesso!</h2>";
        echo "<a href='pessoa.php' class='botao'>Voltar ao Cadastro de Pessoa</a>";
      } elseif ($tipo === 'imovel') {
        echo "<h2>✅ Imóvel cadastrado com sucesso!</h2>";
        echo "<a href='imovel.php' class='botao'>Voltar ao Cadastro de Imóvel</a>";
      } else {
        echo "<h2>Cadastro realizado com sucesso!</h2>";
        echo "<a href='index.html' class='botao'>Voltar ao Início</a>";
      }
    ?>
  </div>
</body>
</html>