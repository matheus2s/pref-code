<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>Erro</title>
  <link rel="stylesheet" href="style.css" />
  <style>
    .mensagem {
      max-width: 500px;
      margin: 100px auto;
      padding: 20px;
      border-radius: 10px;
      background-color: #ffe6e6;
      color: #a94442;
      text-align: center;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    .mensagem h2 {
      font-size: 24px;
    }
    .mensagem p {
      margin: 20px 0;
    }
    .mensagem a {
      display: inline-block;
      margin-top: 10px;
      text-decoration: none;
      background-color: #005bbb;
      color: white;
      padding: 10px 20px;
      border-radius: 6px;
    }
  </style>
</head>
<body>
  <div class="mensagem">
    <h2>❌ Erro no Cadastro</h2>
    <p>
      <?php
        if (isset($_GET['mensagem'])) {
          echo htmlspecialchars($_GET['mensagem']);
        } else {
          echo "Ocorreu um erro inesperado durante o cadastro.";
        }
      ?>
    </p>
    <a href="index.html">Voltar ao Início</a>
  </div>
</body>
</html>
