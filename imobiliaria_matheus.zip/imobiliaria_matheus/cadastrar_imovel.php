<?php
require_once 'conexao.php';

$logradouro = $_POST['logradouro'];
$numero = $_POST['numero'];
$bairro = $_POST['bairro'];
$complemento = $_POST['complemento'] ?? null;
$contribuinte_id = $_POST['contribuinte_id'];

$consulta = $conn->prepare("SELECT id FROM pessoas WHERE id = ?");
$consulta->bind_param("i", $contribuinte_id);
$consulta->execute();
$resultado = $consulta->get_result();

if ($resultado->num_rows === 0) {
    echo "Proprietário {$contribuinte_id} não foi encontrado.";
    exit();
}

$verifica = $conn->prepare("SELECT id FROM imoveis WHERE 
    logradouro = ? AND numero = ? AND bairro = ? AND 
    complemento = ? AND contribuinte_id = ?");
$verifica->bind_param("ssssi", $logradouro, $numero, $bairro, $complemento, $contribuinte_id);
$verifica->execute();
$existe = $verifica->get_result();

if ($existe->num_rows > 0) {
    header("Location: mensagem_erro.php?mensagem=" . urlencode("Já existe um imóvel com esses dados."));
    exit();
}


$sql = "INSERT INTO imoveis (logradouro, numero, bairro, complemento, contribuinte_id) 
        VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $logradouro, $numero, $bairro, $complemento, $contribuinte_id);

if ($stmt->execute()) {
    header("Location: mensagem_sucesso.php?tipo=imovel");
    exit();
} else {
    echo "Erro ao cadastrar imóvel: " . $conn->error;
}

$stmt->close();
$conn->close();
?>